#!/bin/sh
# Placeholder post-image hook. Keep executable if referenced by v86_defconfig.
exit 0
